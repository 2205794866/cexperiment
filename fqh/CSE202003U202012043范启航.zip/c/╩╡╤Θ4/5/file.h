#ifndef _INCLUDE_FILE_2_
#define _INCLUDE_FILE_2_
#include "file2.c"
#endif
#include<stdio.h>
void func1(void);
extern int x,y;
extern char ch;