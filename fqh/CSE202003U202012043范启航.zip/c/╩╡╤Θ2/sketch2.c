#include <stdio.h>

int main()
{
	printf("123\t333");
	return 0;
 } 
