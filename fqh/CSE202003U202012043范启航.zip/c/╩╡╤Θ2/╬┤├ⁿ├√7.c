#include <stdio.h>

int main()
{
	char s[100];
	int flag;
	char c;
	while((scanf("%s", &s)) != EOF)
	{
		i = 0;
		flag = 1;
		
