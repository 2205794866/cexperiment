
    fp2=fopen("d:\\abc2.txt","w+");