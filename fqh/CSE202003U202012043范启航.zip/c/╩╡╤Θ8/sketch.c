#include <stdio.h>

int main()
{
    char c = 0xf;
    printf("%2x", c);
    return 0;
}