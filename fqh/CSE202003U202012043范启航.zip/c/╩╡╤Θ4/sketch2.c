#include <stdio.h>

int main()
{
	int i,j,k;
	scanf("%d%d%d", &i,&j,&k);
	printf("%8d%8d%8d", i, j, k);
	return 0;
}
