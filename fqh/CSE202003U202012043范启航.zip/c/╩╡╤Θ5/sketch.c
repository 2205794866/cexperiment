#include <stdio.h>

int main()
{
	int *p;
	p = 1;
	printf("%d", *p);
	return 0;
 } 
