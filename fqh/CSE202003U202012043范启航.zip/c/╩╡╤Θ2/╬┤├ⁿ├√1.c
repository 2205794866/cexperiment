#include <stdio.h>

int main()
{
	char s[100];
	int i,flag,fu = 0;
	while((scanf("%s", &s)) != EOF )
	{
		i = 0;
		if(s[0] == '-')
		{
			i++;
			fu = 1;
		}
		while( s[i] != '\0')
		{
			if(s[fu] == 0)
			{
				
			}
		}
	}
}
